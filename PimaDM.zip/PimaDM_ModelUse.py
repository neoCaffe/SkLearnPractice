""" PimaDM_ModelUse.py 2021-09-14 neoCaffe
    使用建立好的模型，進行診斷預測 diabetes
    從 PimaDM.csv取兩筆，預測是否發病
"""
print(__doc__)

import pandas as pd
import random
import pickle
''' 載入資料集 '''
df = pd.read_csv('pimaDM.csv')
r,c = df.shape
''' 任意取兩筆 '''
n = random.randint(0,r)
test1 = list(df.iloc[n].values)
m = random.randint(0,r)
test2 = list(df.iloc[m].values)
# 真正的診斷
Dx1 = test1[-1] 
Dx2 = test2[-1]
# 特徵值
test1 = [test1[:-1]]
test2 = [test2[:-1]]


print('隨機取兩筆資料，當測試') 
print(f'特徵:{test1}  診斷: {Dx1}')
print(f'特徵:{test2}  診斷: {Dx2}')


''' 以兩種模型進行預測  '''
print('以兩種模型進行預測''')
mdl_logis = pickle.load(open('DMlr.model', 'rb'))
predict1 = mdl_logis.predict(test1)

mdl_fores = pickle.load(open('DMfs.model', 'rb'))
predict2 = mdl_fores.predict(test2)

print(f'test1 真正診斷是: {Dx1}  以logis模型預測是: {predict1}')
print(f'test2 真正診斷是: {Dx2}  以fores模型預測是: {predict2}')
