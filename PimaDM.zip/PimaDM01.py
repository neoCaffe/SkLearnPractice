''' PimaDM01.py  
    dataset explore Pima Indians diabetes
    2 model for prediction    
    2021-09-14  neoCaffe   '''
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

''' Step1. Load dataset / explore '''
df = pd.read_csv('pimaDM.csv')
df.isnull().sum()
df.describe()
df.info()
df.head()
df.value_counts()
 
''' Step 2. data visulalize 
   畫個Box圖 觀察離散程度   '''
# df0 無病組  df1 有病組      
df0 = df[df['Class'] == 0 ]
df1 = df[df['Class'] == 1 ]

# 把2組畫在一起
fig,axes = plt.subplots(1,2,sharey=True,figsize=(10,6))

axes[0].set_title('Healthy')
axes[1].set_title('DM')

fig.autofmt_xdate(rotation=45)
sns.boxplot(data=df0,ax=axes[0])
sns.boxplot(data=df1,ax=axes[1])

fig.savefig('DM_orig_box.jpg')

# Insulin此特徵數據，離群值似乎很多。算一下統計數據看看
''' Step 3. 統計數據 '''
pd.set_option('display.max_columns',None)  # 顯示所有columns
print(df.describe())
  
''' Step 4. 不合理的異常數據處理  
    血壓、皮膚厚度...多項多筆數據=0 明顯不合理
    將五項特徵 Glucose BP Skin Insulin BMI
    數據=0 and >95percentile者剔除
'''
df_Trim = df      # 處理dataframe
# 95 percentile
#Insulin_q95  = df_Trim['Insulin'].quantile(.95)
#print(f'Insulin 95 percentlie: {Insulin_q95}')
#idxNames = df_Trim[ df_Trim['Insulin'] >= Insulin_q95 ].index
#df_Trim = df.drop(idxNames)
# = 0 者
idxNames = df_Trim[ df_Trim['Insulin']<=0 ].index
df_Trim = df_Trim.drop(idxNames)
print(df_Trim.info())
print(df_Trim)

# Glucose
#Glucose_q95 = df_Trim['Glucose'].quantile(.95)
#print(f'Glucose 95 percentlie: {Glucose_q95}')
#idxNames = df_Trim[ df_Trim['Glucose'] >= Glucose_q95 ].index
#df_Trim = df_Trim.drop(idxNames)
# = 0 者
idxNames = df_Trim[ df_Trim['Glucose']<=0 ].index
df_Trim = df_Trim.drop(idxNames)
print(df_Trim.info())
print(df_Trim)

# BP
#BP_q95 = df_Trim['BP'].quantile(.95)
#print(f'BP 95 percentlie: {BP_q95}')
#idxNames = df_Trim[ df_Trim['BP'] >= BP_q95 ].index
#df_Trim = df_Trim.drop(idxNames)
# = 0 者
idxNames = df_Trim[ df_Trim['BP']<=0 ].index
df_Trim = df_Trim.drop(idxNames)
print(df_Trim.info())
print(df_Trim)

# Skin
#Skin_q95 = df_Trim['Skin'].quantile(.95)
#print(f'Skin 95 percentlie: {Skin_q95}')
#idxNames = df_Trim[ df_Trim['Skin'] >= Skin_q95 ].index
#df_Trim = df_Trim.drop(idxNames)
# = 0 者
idxNames = df_Trim[ df_Trim['Skin']<=0 ].index
df_Trim = df_Trim.drop(idxNames)
print(df_Trim.info())
print(df_Trim)

# BMI
#BMI_q95 = df_Trim['BMI'].quantile(.95)
#print(f'BMI 95 percentlie: {BMI_q95}')
#idxNames = df_Trim[ df_Trim['BMI'] >= BMI_q95 ].index
#df_Trim = df_Trim.drop(idxNames)
# = 0 者
idxNames = df_Trim[ df_Trim['BMI']<=0 ].index
df_Trim = df_Trim.drop(idxNames)
print(df_Trim.info())
print(df_Trim)

df_Trim.to_csv('df_Trim.csv',index=False)
 
''' Step 5. 剩下的資料，再畫一次 boxplot  
   剔除 0 & >95percentile者，剩下 273筆記錄 
   768筆 剩下 35.5% 可用
   如果只剔除 0者，剩下 392筆記錄
'''
df2 = df_Trim[df_Trim['Class'] == 0 ]
df3 = df_Trim[df_Trim['Class'] == 1 ]

fig,axes = plt.subplots(1,2,sharey=True,figsize=(10,6))

axes[0].set_title('Healthy')
axes[1].set_title('DM')

fig.autofmt_xdate(rotation=45)
sns.boxplot(data=df2,ax=axes[0])
sns.boxplot(data=df3,ax=axes[1])

fig.savefig('DM_trim_box.jpg')

''' Step 6. 準備資料，設定 X ,y  '''
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
 
y = df_Trim['Class']    # y 診斷結果= Class
''' 去除 target欄位，留下特徵欄位-->X '''
X = df_Trim.drop(['Class'], axis = 1)
print(X.shape)
print(X.head(5))   # X is a dataframe
print(y[:5])       # y is a Series

# split dataset
X_train, X_test, y_train, y_test = train_test_split(X, y, 
                                                    test_size=0.2,
                                                    stratify=y,
                                                    random_state=0)

#print(len(X_train),len(X_test))

''' Step 7. Build the Model : training'''

# model logistic regression
from sklearn.linear_model import LogisticRegression

logis = LogisticRegression(solver='lbfgs',max_iter = 400)
logis.fit(X_train, y_train)

# model random forest

from sklearn.ensemble import RandomForestClassifier

fores = RandomForestClassifier()
fores.fit(X_train, y_train)

''' Step 8. 評估模型準確度  兩種model的accuracy '''
from sklearn.metrics import accuracy_score

pred_logis = logis.predict(X_test)
pred_fores = fores.predict(X_test)

a1 = accuracy_score(pred_logis, y_test)
a2 = accuracy_score(pred_fores, y_test)
print(f'兩種模型的準確率 accuracy: logis: {a1}  fores: {a2}')

''' Step 9. 儲存模型  '''
import pickle

mdl_DMlr = 'DMlr.model'
pickle.dump(logis, open(mdl_DMlr, 'wb'))
mdl_DMfs = 'DMfs.model'
pickle.dump(fores, open(mdl_DMfs, 'wb'))
print(' 建模完成 models saved ')
